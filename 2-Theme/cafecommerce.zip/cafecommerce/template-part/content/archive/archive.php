<main role="main">
    <section class="archive">
        <div class="container">
			<?php get_template_part('template-part/content/archive/all'); ?>
		</div>
	</section>
</main>
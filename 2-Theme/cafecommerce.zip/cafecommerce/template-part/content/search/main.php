<main role="main">
    <section class="archive-search">
        <div class="container">
			<?php get_template_part('template-part/content/search/all'); ?>
		</div>
	</section>
</main>
<main class="content-post">
    <div class="container">
		<div class="row">
			<div class="col main-post">
				<?php get_template_part('template-part/content/single/main'); ?>
				<?php get_template_part('template-part/content/single/comment-post'); ?>
			</div>
		</div>
	</div>
</main>
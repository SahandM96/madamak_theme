<div class="role-comment" style="display:<?php global $sigma; echo $sigma['role_comment_pro']; ?>">
<?php global $sigma; echo $sigma['role_post_content']; ?>
</div>
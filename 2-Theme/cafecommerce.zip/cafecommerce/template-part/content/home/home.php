<main role="main">
	<?php get_template_part('template-part/content/home/homepage/slider1'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider2'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider3'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider4'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider5'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider6'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider7'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider8'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider9'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider10'); ?>
	<?php get_template_part('template-part/content/home/homepage/slider11'); ?>
</main>

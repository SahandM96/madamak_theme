<main role="main">
<?php get_template_part('template-part/content/product/single-product/main'); ?>
<?php get_template_part('template-part/content/product/single-product/related-product'); ?>
</main>
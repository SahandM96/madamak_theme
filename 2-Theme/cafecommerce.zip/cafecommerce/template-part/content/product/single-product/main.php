<?php if ( have_posts() ) : ?>
	<?php woocommerce_content(); ?>
<?php endif; ?>

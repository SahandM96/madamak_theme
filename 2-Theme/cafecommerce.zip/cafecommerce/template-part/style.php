<style>
p{font-size:<?php global $cafe; echo $cafe['p_font_size']; ?>;}h6 { font-size:<?php global $cafe; echo $cafe['h6_font_size']; ?>}h5 { font-size:<?php global $cafe; echo $cafe['h5_font_size']; ?>}h4 { font-size:<?php global $cafe; echo $cafe['h4_font_size']; ?>}h3 { font-size:<?php global $cafe; echo $cafe['h3_font_size']; ?>}h2 { font-size:<?php global $cafe; echo $cafe['h2_font_size']; ?>}h1 { font-size:<?php global $cafe; echo $cafe['H1_font_size']; ?>}
.navbar .dropdown .dropdown-menu li a,.nav-primary ul.nav>li>a,.menu-panel-v1 ul li a,.top__user__profile_d5 ul.dropdown-menu-3,li{font-family:<?php global $cafe; echo $cafe['lists_font']; ?>!important}
a,h1, h2, h3, h4, h5, h6, input, textarea, pre {font-family:<?php global $cafe; echo $cafe['head_font']; ?>!important;}
body {font-family:<?php global $cafe; echo $cafe['body_font']; ?>!important;background:<?php global $cafe; echo ''  . $cafe['body_back']['background-color']; ?>;}
.navbar-light .form-inline .form-group{border-color:<?php global $cafe; echo ''  .  $cafe['input_serch_border']; ?>}
.navbar-light .form-inline .form-group .btn .fa-search{color:<?php global $cafe; echo ''  .  $cafe['btn_serch_icon']; ?>}
.page-footer{background-color:<?php global $cafe; echo ''  .  $cafe['bg_footer']['background-color']; ?>}
a.back-to-top{background-color:<?php global $cafe; echo ''  .  $cafe['footer_back_topbtn']['background-color']; ?>;border-color:<?php global $cafe; echo ''  .  $cafe['footer_border_topbtn']; ?>;color:<?php global $cafe; echo ''  .  $cafe['footer_icon_color_topbtn']; ?>}
a.back-to-top:hover{background-color:<?php global $cafe; echo ''  .  $cafe['footer_hover_back_topbtn']['background-color']; ?>!important;border-color:<?php global $cafe; echo ''  .  $cafe['footer_hover_border_topbtn']; ?>!important;color:<?php global $cafe; echo ''  .  $cafe['footer_hover_icon_color_topbtn']; ?>!important;}
.page-footer .list-inline-item.instagram a{color: <?php global $cafe; echo ''  .  $cafe['instagram_color']; ?>!important;}
.page-footer .list-inline-item.telegram a{color: <?php global $cafe; echo ''  .  $cafe['telegram_color']; ?>!important;}
.navbar-light .navbar-nav .nav-link{color:<?php global $cafe; echo ''  .  $cafe['menu_header_item_color']; ?>!important;}
.navbar-light .navbar-nav .nav-link:hover{color:<?php global $cafe; echo ''  .  $cafe['menu_header_item_hover_color']; ?>!important;}
.navbar-light .dropdown-menu{background-color:<?php global $cafe; echo ''  .  $cafe['menu_header_dropdown_bg']['background-color']; ?>!important;border-color:<?php global $cafe; echo ''  .  $cafe['menu_header_dropdown_border']; ?>;}
.navbar-light .dropdown a.dropdown-item{color:<?php global $cafe; echo ''  .  $cafe['menu_header_dropdown_item_color']; ?>!important;}
.navbar-light .dropdown a.dropdown-item:hover{color:<?php global $cafe; echo ''  .  $cafe['menu_header_dropdown_item_hover_color']; ?>!important;}
.page-footer .list-inline-item a{color:<?php global $cafe; echo ''  .  $cafe['footer_menu_item_color']; ?>!important;}
.page-footer .list-inline-item a:hover{color:<?php global $cafe; echo ''  .  $cafe['footer_menu_item_hover_color']; ?>!important;}
</style>
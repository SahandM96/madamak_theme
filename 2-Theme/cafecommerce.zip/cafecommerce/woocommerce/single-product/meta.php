<?php
/**
 * Single Product Meta
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/meta.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @package 	WooCommerce/Templates
 * @version     3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;
?>

<div class="info-all info-rating">
    <div class="info-rating_content">
        <?php 
			if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
				?> <span><?php return; ?> نظر</span>
			<?php
			}
			$rating_count = $product->get_rating_count();
			$review_count = $product->get_review_count();
			$average = $product->get_average_rating();	
		?>
		<span><?php echo $review_count ?>
    </div>
    <div class="info-rating_title">
		<span>نظر</span>
    </div>
</div>
		
<?php do_action( 'woocommerce_product_meta_start' ); ?>
					
<div href="#" class="info-all">
    <div class="info-cat_content">
		<?php echo wc_get_product_category_list( $product->get_id(), ', ', '<span>', '</span>' ); ?>
    </div>
    <div class="info-cat_title">
		<span>دسته</span>
    </div>
</div>
	
<?php do_action( 'woocommerce_product_meta_end' ); ?>





<?php
/**
 * Single Product variation-size
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/variation-size.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see        https://docs.woocommerce.com/document/template-structure/
 * @package    WooCommerce/Templates
 * @version    1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>					<?php 
						global $product;
						$met_box = get_post_meta( $product->get_id(), 'size', true );
						if(isset($met_box) && !empty($met_box)) :
					?>
					<div class="info-all">
						<div class="info-size_content">
							<div class="info-size_data">
								<?php 
									echo get_post_meta( $product->get_id(), 'size', true );
								?>
							</div>
						</div>
						<div class="info-size_title">
							<span>حجم</span>
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>
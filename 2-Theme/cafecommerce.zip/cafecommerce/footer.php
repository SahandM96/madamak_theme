<?php wp_footer(); ?>
<a href="#" class="btn btn-outline-success btn-lg back-to-top" role="button" style="display:<?php global $cafe; echo $cafe['backtop_show']; ?>"><i class="fa fa-chevron-up" title="بازگشت به بالا"></i></a>
</body>
<script src="<?php bloginfo('template_url')?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo('template_url')?>/assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php bloginfo('template_url')?>/assets/js/offcanvas.js"></script>
<script src="<?php bloginfo('template_url')?>/assets/js/flickity.pkgd.js"></script>
<script src="<?php bloginfo('template_url')?>/assets/js/fullscreen.js"></script>